import React from "react";

export default function Html() {
  return <div className="html">Html</div>;
}
