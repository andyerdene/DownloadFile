import React from "react";

export default function Condition() {
  return <div>Condition</div>;
}
